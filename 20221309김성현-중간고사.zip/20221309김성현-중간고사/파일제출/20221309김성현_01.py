A = "Hello, IoT"
print(A *3)
print(A[:4])
print(A[-5:])
print(A.lower())
print(A[::-1])